package com.test;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class AutomationExercise {

	public static void main(String[] args) throws InterruptedException {
		System.setProperty("webdriver.chrome.driver","C:\\Users\\CDAC\\Desktop\\SeleniumData\\chromedriver-win32\\chromedriver-win32\\chromedriver.exe");
		WebDriver d=new ChromeDriver();
		d.get("https://automationexercise.com/login");
		String url=d.getCurrentUrl();
		System.out.println("Current page URL: "+url);
		
		//SignUP
		d.findElement(By.xpath("//body/section[@id='form']/div[1]/div[1]/div[3]/div[1]/form[1]/input[2]")).sendKeys("Aditi");
		d.findElement(By.xpath("//body/section[@id='form']/div[1]/div[1]/div[3]/div[1]/form[1]/input[3]")).sendKeys("aditiskl@gmail.com");
		d.findElement(By.xpath("//button[contains(text(),'Signup')]")).click();
		
		//Register 
		d.findElement(By.xpath("//input[@id='id_gender2']")).click();
		d.findElement(By.id("password")).sendKeys("aditi28");
		
		Select day=new Select(d.findElement(By.name("days")));
		day.selectByValue("28");
		
		Select month=new Select(d.findElement(By.id("months")));
		month.selectByIndex(9);
		
		Select year=new Select(d.findElement(By.id("years")));
		year.selectByVisibleText("2001");
		
		d.findElement(By.id("newsletter")).click();
		
		d.findElement(By.xpath("//input[@id='first_name']")).sendKeys("Aditi");
		d.findElement(By.id("last_name")).sendKeys("Kolhe");
		d.findElement(By.name("company")).sendKeys("Infosys");
		
		d.findElement(By.xpath("//input[@name='address1']")).sendKeys("Vadner Bhairav");
		d.findElement(By.xpath("//input[@name='address2']")).sendKeys("Nashik");
		
		Select country=new Select(d.findElement(By.xpath("//select[@id='country']")));
		country.selectByValue("India");
		
		d.findElement(By.xpath("//input[@id='state']")).sendKeys("Maharashtra");
		
		d.findElement(By.xpath("//input[@id='city']")).sendKeys("Nashik");
		
		d.findElement(By.xpath("//input[@id='zipcode']")).sendKeys("423111");
		
		
		d.findElement(By.xpath("//input[@id='mobile_number']")).sendKeys("9822683423");
		
		Thread.sleep(2000);
		d.findElement(By.xpath("//button[contains(text(),'Create Account')]")).click();
		
		Thread.sleep(1000);
		d.findElement(By.xpath("//a[contains(text(),'Continue')]")).click();
		
		d.findElement(By.xpath("//header/div[1]/div[1]/div[1]/div[2]/div[1]/ul[1]/li[4]/a[1]")).click();
		
		//Login
		WebElement uid =d.findElement(By.xpath("//body/section[@id='form']/div[1]/div[1]/div[1]/div[1]/form[1]/input[2]"));
		uid.sendKeys("aditiskl@gmail.com");
		WebElement pass =d.findElement(By.xpath("//body/section[@id='form']/div[1]/div[1]/div[1]/div[1]/form[1]/input[3]"));
		pass.sendKeys("aditi28");
		Thread.sleep(1000);
		
		System.out.println("Login ID: "+uid.getAttribute("value"));
		System.out.println("password: "+pass.getAttribute("value"));
		d.findElement(By.xpath("//button[contains(text(),'Login')]")).click();
		
		
	}

}
